﻿using System;

namespace MCdonald
{
    class Program
    {
        static void Main(string[] args)
        {

            //variabili
            bool valid, isDone = true;
            int quantita = 0, countD = 0, countS = 0, countF = 0, countC = 0, countZ = 0;
            double totale = 0.0, totalD = 0.0, totalS = 0.0, totalF = 0.0, totalC = 0.0, totalZ = 0.0;
            int opzione;
            string selec, selec2, cont;

            // valori temp per calcolare il prezzo
            double temp, temp2, saldoD = 0;

            Console.WriteLine("CIAO E BENEVENUTO AL MCDONALD");

            do
            {
                Console.WriteLine("\nMenu: ");
                Console.WriteLine("(1)Big Mac\t\t$ 6.80");
                Console.WriteLine("(2)Gran Crispy McBacon\t\t$ 7.90");
                Console.WriteLine("(3)Crispy McWrap\t\t$ 6.40");
                Console.WriteLine("(4)My Selection BBQ\t\t$ 8.60");
                Console.WriteLine("(5)Cheeseburger\t\t$ 1.20");

                Console.WriteLine("Scegli un opzione (#) per proseguire: ");
                selec = Console.ReadLine();
                opzione = Convert.ToInt32(selec);

                if (opzione == 1 || opzione == 2 || opzione == 3 || opzione == 4 || opzione == 5)
                {
                    valid = true;
                }
                else
                {
                    Console.WriteLine("Ops qualcosa è andato storto :(");
                    valid = false;
                    break;

                }

                if (valid)
                {
                    Console.WriteLine("Quanti ne vuoi ordinare? ");
                    selec2 = Console.ReadLine();
                    quantita = Convert.ToInt32(selec2);

                    switch (opzione)
                    {
                        case 1:
                            //big mac
                            countD += quantita;
                            totalD += totalD + (quantita * 6.80);
                            break;
                        case 2:
                            // crispy
                            countD += quantita;
                            totalS = totalS + (quantita * 7.90);
                            break;
                        case 3:
                            // mcwrap
                            countF += quantita;
                            totalF = totalF + (quantita * 6.40);
                            break;
                        case 4:
                            // myselection
                            countC += quantita;
                            totalC = totalC + (quantita * 8.60);
                            break;
                        case 5:
                            // cheeseburger
                            countZ += quantita;
                            totalZ = totalZ + (quantita * 1.20);
                            break;
                    }

                    //totale da pagare
                    totale = totalD + totalS + totalF + totalC + totalZ;
                    Console.WriteLine("Totale: $" + totale.ToString("F"));
                }

     
                Console.WriteLine("\nHai finito di ordinare (Y or N)? ");
                cont = Console.ReadLine().ToUpper();

                if (cont == "Y")
                    isDone = false;

            } while (isDone);

            //calcolo 9% di iva
            double tax;
            tax = .09 * totale;
            tax = Math.Round(tax, 2);

            //stampa gli ordini
            Console.WriteLine("Ordine: ");

            if (countD > 0)
                Console.WriteLine("Big Mac\t\t\t(" + countD + ")");

            if (countS > 0)
                Console.WriteLine("Gran Crispy McBacon\t\t\t(" + countS + ")");

            if (countF > 0)
                Console.WriteLine("Crispy McWrap\t\t\t(" + countF + ")");

            if (countC > 0)
                Console.WriteLine("My Selection BBQ\t\t\t(" + countC + ")");

            if (countZ > 0)
                Console.WriteLine("Cheeseburger\t\t\t(" + countZ + ")");

            Console.WriteLine("IVA\t\t\t$" + tax.ToString("F"));

            //aggiorna il totale
            totale += tax;

            // scontrino
            Console.WriteLine("\nSCONTRINO");
            Console.WriteLine("------------------------");
            if (countD > 0)
                Console.WriteLine("Big Mac(" + countD + ")\t\t\t$" + totalD.ToString("F"));
                   
            if (countS > 0)
                Console.WriteLine("Gran Crispy McBacon(" + countS + ")\t\t\t$" + totalS.ToString("F"));

            if (countF > 0)
                Console.WriteLine("Crispy McWrap(" + countF + ")\t\t\t$" + totalF.ToString("F"));

            if (countC > 0)
                Console.WriteLine("My Selection BBQ(" + countC + ")\t\t\t$" + totalC.ToString("F"));

            if (countZ > 0)
                Console.WriteLine("Cheeseburger(" + countZ + ")\t\t\t$" + totalZ.ToString("F"));

            Console.WriteLine("IVA\t\t\t\t$" + tax.ToString("F"));
            Console.WriteLine("\nTOTALE\t\t\t\t$" + totale.ToString("F"));
            Console.WriteLine("\nBUON APPETITO E GRAZIE <3");

        }
    }
}
