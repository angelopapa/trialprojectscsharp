﻿using System;

namespace Piramide
{
    class Program
    {
        static void Main(string[] args)
        {
            int row, space, star, totalrows;

            Console.WriteLine("Inserisci il numero di *: ");
            totalrows = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(" ");

            for (row =1; row<=totalrows; row++)
            {
                for (space=1; space<=totalrows-row; space++)
                {
                    Console.Write(" ");
                }

                for (star=1; star<=(row*2); star++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
            Console.ReadLine();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
        }
        
       
    }
}
