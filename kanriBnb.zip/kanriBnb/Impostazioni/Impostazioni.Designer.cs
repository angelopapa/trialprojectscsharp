﻿
namespace kanriBnb.Impostazioni
{
    partial class Impostazioni
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Impostazioni));
            this.lblNomeStruttura = new System.Windows.Forms.Label();
            this.txtNomeStruttura = new System.Windows.Forms.TextBox();
            this.txtTasse = new System.Windows.Forms.TextBox();
            this.lblTasseSoggiorno = new System.Windows.Forms.Label();
            this.btnSalvaImpostazioni = new System.Windows.Forms.Button();
            this.btnAnnullaImpostazioni = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNomeStruttura
            // 
            this.lblNomeStruttura.AccessibleName = "lblNomeStruttura";
            this.lblNomeStruttura.AutoSize = true;
            this.lblNomeStruttura.ForeColor = System.Drawing.Color.White;
            this.lblNomeStruttura.Location = new System.Drawing.Point(44, 19);
            this.lblNomeStruttura.Name = "lblNomeStruttura";
            this.lblNomeStruttura.Size = new System.Drawing.Size(108, 17);
            this.lblNomeStruttura.TabIndex = 0;
            this.lblNomeStruttura.Text = "Nome Struttura:";
            // 
            // txtNomeStruttura
            // 
            this.txtNomeStruttura.Location = new System.Drawing.Point(275, 16);
            this.txtNomeStruttura.Name = "txtNomeStruttura";
            this.txtNomeStruttura.Size = new System.Drawing.Size(234, 22);
            this.txtNomeStruttura.TabIndex = 1;
            // 
            // txtTasse
            // 
            this.txtTasse.Location = new System.Drawing.Point(275, 53);
            this.txtTasse.Name = "txtTasse";
            this.txtTasse.Size = new System.Drawing.Size(100, 22);
            this.txtTasse.TabIndex = 3;
            // 
            // lblTasseSoggiorno
            // 
            this.lblTasseSoggiorno.AccessibleName = "lblTasseSoggiorno";
            this.lblTasseSoggiorno.AutoSize = true;
            this.lblTasseSoggiorno.ForeColor = System.Drawing.Color.White;
            this.lblTasseSoggiorno.Location = new System.Drawing.Point(44, 56);
            this.lblTasseSoggiorno.Name = "lblTasseSoggiorno";
            this.lblTasseSoggiorno.Size = new System.Drawing.Size(135, 17);
            this.lblTasseSoggiorno.TabIndex = 2;
            this.lblTasseSoggiorno.Text = "Tasse di Soggiorno:";
            // 
            // btnSalvaImpostazioni
            // 
            this.btnSalvaImpostazioni.AccessibleName = "btnSalvaImpostazioni";
            this.btnSalvaImpostazioni.Location = new System.Drawing.Point(362, 232);
            this.btnSalvaImpostazioni.Name = "btnSalvaImpostazioni";
            this.btnSalvaImpostazioni.Size = new System.Drawing.Size(83, 31);
            this.btnSalvaImpostazioni.TabIndex = 9;
            this.btnSalvaImpostazioni.Text = "Salva";
            this.btnSalvaImpostazioni.UseVisualStyleBackColor = true;
            this.btnSalvaImpostazioni.Click += new System.EventHandler(this.btnSalvaImpostazioni_Click);
            // 
            // btnAnnullaImpostazioni
            // 
            this.btnAnnullaImpostazioni.AccessibleName = "btnAnnullaImpostazioni";
            this.btnAnnullaImpostazioni.Location = new System.Drawing.Point(460, 232);
            this.btnAnnullaImpostazioni.Name = "btnAnnullaImpostazioni";
            this.btnAnnullaImpostazioni.Size = new System.Drawing.Size(83, 31);
            this.btnAnnullaImpostazioni.TabIndex = 10;
            this.btnAnnullaImpostazioni.Text = "Annulla";
            this.btnAnnullaImpostazioni.UseVisualStyleBackColor = true;
            this.btnAnnullaImpostazioni.Click += new System.EventHandler(this.btnAnnullaImpostazioni_Click);
            // 
            // Impostazioni
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(99)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(555, 271);
            this.Controls.Add(this.btnAnnullaImpostazioni);
            this.Controls.Add(this.btnSalvaImpostazioni);
            this.Controls.Add(this.txtTasse);
            this.Controls.Add(this.lblTasseSoggiorno);
            this.Controls.Add(this.txtNomeStruttura);
            this.Controls.Add(this.lblNomeStruttura);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Impostazioni";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Impostazioni";
            this.Load += new System.EventHandler(this.Impostazioni_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeStruttura;
        private System.Windows.Forms.TextBox txtNomeStruttura;
        private System.Windows.Forms.TextBox txtTasse;
        private System.Windows.Forms.Label lblTasseSoggiorno;
        private System.Windows.Forms.Button btnSalvaImpostazioni;
        private System.Windows.Forms.Button btnAnnullaImpostazioni;
    }
}