﻿
namespace kanriBnb.Impostazioni
{
    partial class Impostazioni
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Impostazioni));
            this.lblNomeStruttura = new System.Windows.Forms.Label();
            this.txtNomeStruttura = new System.Windows.Forms.TextBox();
            this.txtTasse = new System.Windows.Forms.TextBox();
            this.lblTasseSoggiorno = new System.Windows.Forms.Label();
            this.btnSalvaImpostazioni = new System.Windows.Forms.Button();
            this.btnAnnullaImpostazioni = new System.Windows.Forms.Button();
            this.grpTasse = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.grpTasse.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNomeStruttura
            // 
            this.lblNomeStruttura.AccessibleName = "lblNomeStruttura";
            this.lblNomeStruttura.AutoSize = true;
            this.lblNomeStruttura.ForeColor = System.Drawing.Color.White;
            this.lblNomeStruttura.Location = new System.Drawing.Point(16, 39);
            this.lblNomeStruttura.Name = "lblNomeStruttura";
            this.lblNomeStruttura.Size = new System.Drawing.Size(108, 17);
            this.lblNomeStruttura.TabIndex = 0;
            this.lblNomeStruttura.Text = "Nome Struttura:";
            // 
            // txtNomeStruttura
            // 
            this.txtNomeStruttura.Location = new System.Drawing.Point(130, 39);
            this.txtNomeStruttura.Name = "txtNomeStruttura";
            this.txtNomeStruttura.Size = new System.Drawing.Size(234, 22);
            this.txtNomeStruttura.TabIndex = 1;
            // 
            // txtTasse
            // 
            this.txtTasse.Location = new System.Drawing.Point(130, 86);
            this.txtTasse.Name = "txtTasse";
            this.txtTasse.Size = new System.Drawing.Size(58, 22);
            this.txtTasse.TabIndex = 3;
            // 
            // lblTasseSoggiorno
            // 
            this.lblTasseSoggiorno.AccessibleName = "lblTasseSoggiorno";
            this.lblTasseSoggiorno.AutoSize = true;
            this.lblTasseSoggiorno.ForeColor = System.Drawing.Color.White;
            this.lblTasseSoggiorno.Location = new System.Drawing.Point(64, 89);
            this.lblTasseSoggiorno.Name = "lblTasseSoggiorno";
            this.lblTasseSoggiorno.Size = new System.Drawing.Size(51, 17);
            this.lblTasseSoggiorno.TabIndex = 2;
            this.lblTasseSoggiorno.Text = "Tassa:";
            // 
            // btnSalvaImpostazioni
            // 
            this.btnSalvaImpostazioni.AccessibleName = "btnSalvaImpostazioni";
            this.btnSalvaImpostazioni.Location = new System.Drawing.Point(183, 141);
            this.btnSalvaImpostazioni.Name = "btnSalvaImpostazioni";
            this.btnSalvaImpostazioni.Size = new System.Drawing.Size(83, 31);
            this.btnSalvaImpostazioni.TabIndex = 9;
            this.btnSalvaImpostazioni.Text = "Salva";
            this.btnSalvaImpostazioni.UseVisualStyleBackColor = true;
            this.btnSalvaImpostazioni.Click += new System.EventHandler(this.btnSalvaImpostazioni_Click);
            // 
            // btnAnnullaImpostazioni
            // 
            this.btnAnnullaImpostazioni.AccessibleName = "btnAnnullaImpostazioni";
            this.btnAnnullaImpostazioni.Location = new System.Drawing.Point(281, 141);
            this.btnAnnullaImpostazioni.Name = "btnAnnullaImpostazioni";
            this.btnAnnullaImpostazioni.Size = new System.Drawing.Size(83, 31);
            this.btnAnnullaImpostazioni.TabIndex = 10;
            this.btnAnnullaImpostazioni.Text = "Annulla";
            this.btnAnnullaImpostazioni.UseVisualStyleBackColor = true;
            this.btnAnnullaImpostazioni.Click += new System.EventHandler(this.btnAnnullaImpostazioni_Click);
            // 
            // grpTasse
            // 
            this.grpTasse.Controls.Add(this.lblNomeStruttura);
            this.grpTasse.Controls.Add(this.btnSalvaImpostazioni);
            this.grpTasse.Controls.Add(this.btnAnnullaImpostazioni);
            this.grpTasse.Controls.Add(this.txtNomeStruttura);
            this.grpTasse.Controls.Add(this.lblTasseSoggiorno);
            this.grpTasse.Controls.Add(this.txtTasse);
            this.grpTasse.Location = new System.Drawing.Point(164, 39);
            this.grpTasse.Name = "grpTasse";
            this.grpTasse.Size = new System.Drawing.Size(388, 189);
            this.grpTasse.TabIndex = 11;
            this.grpTasse.TabStop = false;
            this.grpTasse.Text = "Inserisci Tassa di Soggiorno";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(33, 39);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 50);
            this.button1.TabIndex = 12;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(124, 443);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(325, 50);
            this.button2.TabIndex = 13;
            this.button2.Text = "AGGIORNAMENTO SOFTWARE";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // Impostazioni
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(99)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(564, 534);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.grpTasse);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Impostazioni";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Impostazioni";
            this.Load += new System.EventHandler(this.Impostazioni_Load);
            this.grpTasse.ResumeLayout(false);
            this.grpTasse.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblNomeStruttura;
        private System.Windows.Forms.TextBox txtNomeStruttura;
        private System.Windows.Forms.TextBox txtTasse;
        private System.Windows.Forms.Label lblTasseSoggiorno;
        private System.Windows.Forms.Button btnSalvaImpostazioni;
        private System.Windows.Forms.Button btnAnnullaImpostazioni;
        private System.Windows.Forms.GroupBox grpTasse;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}