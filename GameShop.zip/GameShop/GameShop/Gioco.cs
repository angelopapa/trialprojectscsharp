﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameShop
{
    class Gioco
    {
        public int id { get; set; }
        public string nome {get; set;}
        public string categoria { get; set; }
        public int pegi { get; set; }
        public double prezzo { get; set; }

        public Gioco(int id, string nome, string categoria, int pegi, double prezzo)
        {
            this.id = id;
            this.nome = nome;
            this.categoria = categoria;
            this.pegi = pegi;
            this.prezzo = prezzo;
        }

        public void ToString()
        {

            Console.WriteLine(id + " " + nome + " " + " " + categoria + " "  + " "+ pegi + " " + " " + "$" + " " + prezzo);
        }
    }
}
