﻿using System;
using System.Collections.Generic;

namespace GameShop
{
    class Program
    {
        
        static void Main(string[] args)
        {
           
            int quantita = 1, giocoD = 1, giocoS = 1, giocoF = 1, giocoC = 1, giocoG = 1;
            double totale = 0.0, totalD = 0.0, totalS = 0.0, totalF = 0.0, totalC = 0.0, totalG = 0.0;
            int opzione = 5;
            string visualizza;
            string scelta;
            bool verifica = true;
            


            string consolePs = "PlayStation 4/5";
            string consoleN = "Nintendo Switch";
            string consoleP = "PC";
            string consoleO = "Xbox One";
            string consoleX = "Xbox Series X/S";
            

            Console.WriteLine("BENVENUTO IN QUESTO MINI GAMESHOP!");

            Console.WriteLine("\nLISTINO GIOCHI");

            List<Gioco> giochi = new List<Gioco>();
            Gioco gioco1 = new Gioco(1, "Dragon Ball Z Kakarot", "Action & Fighter", 18, 59.99);
            giochi.Add(gioco1);
            Gioco gioco2 = new Gioco(2, "Super Smash Bros Ultimate", "Action & Fighter", 12, 59.99);
            giochi.Add(gioco2);
            Gioco gioco3 = new Gioco(3, "Formula 1 2022", "Formula 1", 3, 34.99);
            giochi.Add(gioco3);
            Gioco gioco4 = new Gioco(4, "Grand Theft Auto V", "Adventure", 18, 16);
            giochi.Add(gioco4);
            Gioco gioco5 = new Gioco(5, "Fifa 23", "Football", 3, 69.99);
            giochi.Add(gioco5);

            foreach (Gioco gioco in giochi)
            {
                gioco.ToString();
            }

            // ciclo do while con switch
            do
            {

                Console.WriteLine("\nScegli il gioco che vuoi visualizzare: ");
                visualizza = Console.ReadLine();
                opzione = Convert.ToInt32(visualizza);


                switch (opzione)
                {
                    case 1:
                        //dragon ball
                        Console.WriteLine("Dragon Ball Z Kakarot");
                        DescrizioneD();
                        Console.WriteLine($"Pattaforme: {consolePs}, {consoleN}, {consoleO}, {consoleX}, {consoleP}" + "\nPrezzo: $  59.99");
                        giocoD += quantita;
                        totalD += totalD + (quantita * 59.99);
                        break;

                    case 2:
                        //Super Smash bros
                        Console.WriteLine("Super Smash Bros Ultimate");
                        DescrizioneS();
                        Console.WriteLine($"Console: {consoleN}" + "\nPrezzo: $  59.99");
                        giocoS += quantita;
                        totalS = totalS + (quantita * 59.99);
                        break;

                    case 3:
                        //f1
                        Console.WriteLine("Formula 1 2022");
                        DescrizioneF();
                        Console.WriteLine($"Console: {consolePs}, {consoleO}, {consoleX}, {consoleP}" + "\nPrezzo: $  34.99");
                        giocoF += quantita;
                        totalF = totalF + (quantita * 34.99);
                        break;

                    case 4:
                        //gta
                        Console.WriteLine("Grand Theft Auto V");
                        DescrizioneG();
                        Console.WriteLine($"Console: {consolePs}, {consoleO}, {consoleX}, {consoleP}" + "\nPrezzo: $  16");
                        giocoC += quantita;
                        totalC = totalC + (quantita * 16);
                        break;

                    case 5:
                        //fifa
                        Console.WriteLine("Fifa 23");
                        DescrizioneC();
                        Console.WriteLine($"Console: {consolePs}, {consoleN}, {consoleO},{consoleX}, {consoleP}," + "\nPrezzo: $  69.99");   
                        giocoG += quantita;
                        totalG = totalG + (quantita * 69.99);
                        break;
                }

                Console.WriteLine("\nVuoi procedere all'acquisto (Y or N)? ");
                scelta = Console.ReadLine().ToUpper();

                if (scelta == "Y")
                    verifica = false;
                    

            } while (verifica);
        

         
            Console.WriteLine("\nSCONTRINO");
            Console.WriteLine("------------------------------------------");

            if (giocoD > 0)
                Console.WriteLine("Dragon Ball Z Kakarot\t\t\t(" + giocoD + ")\t\t\t$" + totalD.ToString());

            if (giocoS > 0)
                Console.WriteLine("Super Smash Bros Ultimate\t\t\t(" + giocoS + ")\t\t\t$" + totalS.ToString());

            if (giocoF > 0)
                Console.WriteLine("Formula 1 2022\t\t\t(" + giocoF + ")\t\t\t$" + totalF.ToString());

            if (giocoC > 0)
                Console.WriteLine("Grand Theft Auto V\t\t\t(" + giocoC + ")\t\t\t$" + totalC.ToString());

            if (giocoG > 0)
                Console.WriteLine("Fifa 23\t\t\t(" + giocoG + ")\t\t\t$" + totalG.ToString());

            Console.WriteLine("\nTOTALE\t\t\t\t$" + totale.ToString("F"));
            Console.WriteLine("\nGRAZIE PER AVER ACQUISTATO DA NOI :D");



        }
       static void DescrizioneD()
        {
            Console.WriteLine("Rivivi le emozionanti avventure di Goku in DRAGON BALL Z KAKAROT!");
        }

      static void DescrizioneS()
        {
            Console.WriteLine("Mondi e personaggi leggendari si incontrano per la sfida definitiva su Nintendo Switch in un nuovo Super Smash Bros.!");
        }

       static void DescrizioneF()
        {
            Console.WriteLine("ntra nella nuova era della Formula 1® in EA SPORTS™ F1® 22, il videogioco ufficiale del FIA Formula One World Championship™ 2022!");
        }

        static void DescrizioneG()
        {
            Console.WriteLine("Los Santos: un'enorme e soleggiata metropoli piena di sedicenti guru, attricette e celebrità sul viale del tramonto.");
        }
        static void DescrizioneC()
        {
            Console.WriteLine("EA SPORTS™ FIFA 23 porta l'azione e il realismo del gioco più bello del mondo ad un nuovo livello.");
        }
    }
}


